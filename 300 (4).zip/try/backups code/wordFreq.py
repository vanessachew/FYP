import nltk
from nltk.corpus import stopwords
import pandas as pd 
import string
import re
import heapq 

# Download NLTK resources
nltk.download('stopwords')
nltk.download('punkt')

# Load the DataFrame
df = pd.read_csv("Book1.csv")

df.info()

# Function to remove special characters
def remove_special_characters(text):
    allowed_chars = set(string.ascii_letters + ' ')  # Define allowed characters
    clean_text = ''.join(char for char in text if char in allowed_chars)  # Filter out special characters
    return clean_text

# Define a function to remove links from a string
def remove_links(text):
    return re.sub(r'http\S+', '', text)

# Remove links
df["clean_text"] = df["abstract"].apply(remove_links)

# Convert text to lowercase
df["clean_text"] = df["clean_text"].str.lower()

# Remove special characters
df["clean_text"] = df["clean_text"].apply(remove_special_characters) 

# Load stopwords
stop_list = set(stopwords.words('english'))
stop_list.update(["extra", "certainly", "also", "always"])

# Remove stopwords
def remove_stopwords(text):
    words = text.split()
    clean_words = [word for word in words if word not in stop_list]
    clean_text = ' '.join(clean_words)
    return clean_text

# Apply stopwords removal
df["clean_text"] = df["clean_text"].apply(remove_stopwords)

# Tokenize the text into sentences
df['sentences'] = df['clean_text'].apply(nltk.sent_tokenize)

# Tokenize the text into words
df['words'] = df['clean_text'].apply(nltk.word_tokenize)

for index, row in df.iterrows():

    # Tokenize the text into words
    words = nltk.word_tokenize(row['clean_text'])

    # Count the frequency of each word for the current row
    word_freq = {}
    for word in words:
        if word not in word_freq:
            word_freq[word] = 1
        else:
            word_freq[word] += 1

    # Display the 10 most frequent words
    top_words = heapq.nlargest(10, word_freq, key=word_freq.get)

    print(f"\nTop 10 Most Frequent Words for Row {index + 1}:")
    for word in top_words:
        print(f"{word}: {word_freq[word]} times")

# =========================================================================================

# # Count the frequency of each word
# word_freq = {}
# for words in df['words']:
#     for word in words:
#         if word not in word_freq:
#             word_freq[word] = 1
#         else:
#             word_freq[word] += 1

# # Display or store the word frequencies
# # Display the top 10 most frequent words
# top_words = heapq.nlargest(10, word_freq, key=word_freq.get)

# print("Top 10 Most Frequent Words:")
# for word in top_words:
#     print(f"{word}: {word_freq[word]} times")


# # Function to compute word frequency
# def word_frequency(text):
#     word_frequencies = {}
#     for word in nltk.word_tokenize(text):
#         if word not in stop_list:
#             if word not in word_frequencies.keys():
#                 word_frequencies[word] = 1
#             else:
#                 word_frequencies[word] += 1
#     return word_frequencies



# # Function to compute sentence score based on word frequency
# def score_sentences(sentences, word_frequencies):
#     sentence_scores = {}
#     for sent in sentences:
#         for word in nltk.word_tokenize(sent.lower()):
#             if word in word_frequencies.keys():
#                 if len(sent.split(' ')) < 10:  # Limit the sentence length
#                     if sent not in sentence_scores.keys():
#                         sentence_scores[sent] = word_frequencies[word]
#                     else:
#                         sentence_scores[sent] += word_frequencies[word]
#     return sentence_scores

# # Function to get the most important sentences
# def get_summary(row):
#     sentences = row['sentences']
#     sentence_scores = score_sentences(row['clean_text'], word_frequency(row['clean_text']))
#     num_sentences = 3  # Number of sentences to extract as summary
#     # sorted_scores = sorted(sentence_scores.items(), key=lambda x: x[1], reverse=True)
#     summary_sentences = [sentence[0] for sentence]
#     return summary_sentences

# # Apply the summarization function to each row in the DataFrame
# df['summary'] = df.apply(get_summary, axis=1)

# # Print the summary
# for index, row in df.iterrows():
#     print(f"Summary for {row['name']}:")
#     print('\n'.join(row['summary']))
#     print('\n')
