import nltk
from rake_nltk import Rake
import pandas as pd 
from nltk.tokenize import word_tokenize, sent_tokenize
# from nltk.corpus import stopwords

# nltk.download('stopwords')
nltk.download('punkt')

# Load the DataFrame
df = pd.read_csv("Book1.csv")
# df.info()

# Set display options
pd.set_option('display.max_colwidth', 500)

# Initialize RAKE
r = Rake(include_repeated_phrases= False)

# List of columns to use for RAKE
columns_use = ['abstract'] 

# Extract key phrases using RAKE for multiple columns
key_phrases_dict = {}  # Dictionary to store key phrases for each column

for column_name in columns_use:
    key_phrases = []  # List to store key phrases for the current column
    for text in df[column_name]:
        r.extract_keywords_from_text(text)
        phrases_with_scores = r.get_ranked_phrases_with_scores()
        
        unique_phrases = set()  # Set to store unique phrases
        
        # Loop through phrases with scores and add unique phrases
        for score, phrase in phrases_with_scores:
            if phrase not in unique_phrases:
                unique_phrases.add(phrase)
                key_phrases.append((score, phrase))
    
    key_phrases_dict[column_name] = key_phrases  # Store key phrases for the current column

for column_name in columns_use:
    key_phrases = []  # List to store key phrases for the current column
    for text in df[column_name]:
        r.extract_keywords_from_text(text)
        phrases = r.get_ranked_phrases_with_scores()
        key_phrases.append(phrases[:10]) 
    key_phrases_dict[column_name] = key_phrases  # Store key phrases for the current column

# Add key phrases with scores to DataFrame for each column
for column_name, key_phrases in key_phrases_dict.items():
    df[column_name + "_key_phrases_with_scores"] = key_phrases

# # Print out key phrases for each column
# for column_name, key_phrases in key_phrases_dict.items():
#     print(f"Key Phrases for Column '{column_name}':")
#     for index, phrases in enumerate(key_phrases):
#         print(f"Row {index}:")
#         # Print top 10 key phrases for the current row
#         for score, phrase in phrases:
#             print(f"Phrase: {phrase}, Score: {score}")
#     print()

# Create a dictionary to store all phrase-score pairs
all_phrase_scores = {}

# Iterate over the key_phrases_dict
for column_name, key_phrases in key_phrases_dict.items():
    for index, phrases in enumerate(key_phrases):
        for score, phrase in phrases:
            # Check if the phrase already exists in the dictionary
            if phrase in all_phrase_scores:
                # If the phrase exists, update its score if the new score is higher
                if score > all_phrase_scores[phrase]:
                    all_phrase_scores[phrase] = score
            else:
                # If the phrase doesn't exist, add it to the dictionary
                all_phrase_scores[phrase] = score

# # Print out all phrase-score pairs
# print("All Phrase-Score Pairs:")
# for phrase, score in all_phrase_scores.items():
#     print(f"Phrase: {phrase}, Score: {score}")

# Create a function to check if a phrase belongs to a single sentence
def is_single_sentence_phrase(phrase, text):
    # Tokenize the text into sentences
    sentences = sent_tokenize(text)
    count = 0
    for sentence in sentences:
        # Check if the phrase is in the sentence
        if phrase in sentence:
            count += 1
    # If the phrase appears in only one sentence, return True
    return count == 1

# Iterate over the key_phrases_dict and filter out phrases belonging to a single sentence
for column_name, key_phrases in key_phrases_dict.items():
    single_sentence_phrases = []
    for index, phrases in enumerate(key_phrases):
        for score, phrase in phrases:
            # Check if the phrase belongs to a single sentence
            if is_single_sentence_phrase(phrase, df.loc[index, column_name]):
                single_sentence_phrases.append((score, phrase))
    # Update the key_phrases_dict with only single sentence phrases
    key_phrases_dict[column_name] = single_sentence_phrases

# Print out key phrases for each column
for column_name, key_phrases in key_phrases_dict.items():
    print(f"Key Phrases for Column '{column_name}':")
    for score, phrase in key_phrases:
        print(f"Phrase: {phrase}, Score: {score}")
    print()


# for phrases in key_phrases_dict.items():
#     for sent in sent_tokenize('abstract'):
#         for keys in 


#         # Tokenize text into sentences
#         sentences = sent_tokenize(text)

#         # Filter phrases to check if they are derived from single sentences
#         single_sentence_phrases = []
#         for score, phrase in phrases:
#             # Check if any sentence contains the entire phrase
#             if any(phrase.lower() in sentence.lower() for sentence in sentences):
#                 single_sentence_phrases.append((score, phrase))
#         key_phrases.append(single_sentence_phrases[:10])
#     key_phrases_dict[column_name] = key_phrases  # Store key phrases for the current column

# # Add key phrases with scores to DataFrame for each column
# for column_name, key_phrases in key_phrases_dict.items():
#     df[column_name + "_key_phrases_with_scores"] = key_phrases

# # Print out key phrases for each column
# for column_name, key_phrases in key_phrases_dict.items():
#     print(f"Key Phrases with Scores for Column '{column_name}':")
#     for index, phrases in enumerate(key_phrases):
#         print(f"Row {index}:")
#         # Print top 10 key phrases with scores for the current row
#         for rank, (score, phrase) in enumerate(phrases[:10], start=1):
#             print(f"Phrase: {phrase}, Score: {score}, Rank: {rank}")
#     print()

# # =================================================================================
    
# for column_name in columns_use:
#     key_phrases = []  # List to store key phrases for the current column
#     for text in df[column_name]:
#         r.extract_keywords_from_text(text)
#         phrases = r.get_ranked_phrases_with_scores()
#         key_phrases.append(phrases[:10]) 
#     key_phrases_dict[column_name] = key_phrases  # Store key phrases for the current column

# # Add key phrases with scores to DataFrame for each column
# for column_name, key_phrases in key_phrases_dict.items():
#     df[column_name + "_key_phrases_with_scores"] = key_phrases

# # Print out key phrases for each column
# for column_name, key_phrases in key_phrases_dict.items():
#     print(f"Key Phrases with Scores for Column '{column_name}':")
#     for index, phrases in enumerate(key_phrases):
#         print(f"Row {index}:")
#         # Print top 10 key phrases with scores for the current row
#         for rank, (score, phrase) in enumerate(phrases[:10], start=1):
#             print(f"Phrase: {phrase}, Score: {score}, Rank: {rank}")
#     print()
