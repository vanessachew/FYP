import nltk
from rake_nltk import Rake
import pandas as pd 
from nltk.tokenize import sent_tokenize

# Download necessary NLTK resources
nltk.download('punkt')
nltk.download('stopwords')

# Load the DataFrame or your text corpus
df = pd.read_csv("Book1.csv")

# Initialize RAKE
r = Rake(include_repeated_phrases=False)

# use this to store keyword-score pair for abstract and ChatGPT
keyword_score_abstract = {}
keyword_score_gpt = {}

# Create a dictionary to store all summary sentences
all_summary_sentences = {}

# create a list to store summary of each row in column
summary = []

# Iterate through each row in the DataFrame
for index, row in df.iterrows():
    abstract = row['text']
    gpt_summary = row['summary_ChatGPT_15_sentences']
    
    # Extract keywords using RAKE for the abstract
    r.extract_keywords_from_text(abstract)
    keywords_abstract = r.get_ranked_phrases_with_scores()
    
    # Extract keywords using RAKE for the GPT summary
    r.extract_keywords_from_text(gpt_summary)
    keywords_gpt = r.get_ranked_phrases_with_scores()
    
    # Store keyword-score pairs in the dictionary for abstract
    for score, keyword in keywords_abstract:
        if keyword in keyword_score_abstract:
            keyword_score_abstract[keyword] = max(keyword_score_abstract[keyword], score)
        else:
            keyword_score_abstract[keyword] = score
    
    # Store keyword-score pairs in the dictionary for GPT summary
    for score, keyword in keywords_gpt:
        if keyword in keyword_score_gpt:
            keyword_score_gpt[keyword] = max(keyword_score_gpt[keyword], score)
        else:
            keyword_score_gpt[keyword] = score
    
    # Append the summary for each row to the summary list
    summary.append((abstract, gpt_summary))

     # Store all summary sentences in the dictionary
    all_summary_sentences[index] = {
        'abstract': [],
        'gpt_summary': []
    }
    
    # Process abstract summary sentences
    for sentence_abs in sent_tokenize(abstract)[:10]:
        sentence_score_abs = sum(keyword_score_abstract.get(word, 0) for word in sentence_abs.split())
        if sentence_score_abs > 0:
            all_summary_sentences[index]['abstract'].append((sentence_abs.strip(), sentence_score_abs))
    
    # Process ChatGPT summary sentences
    for sentence_gpt in sent_tokenize(gpt_summary)[:10]:
        sentence_score_gpt = sum(keyword_score_gpt.get(word, 0) for word in sentence_gpt.split())
        if sentence_score_gpt > 0:
            all_summary_sentences[index]['gpt_summary'].append((sentence_gpt.strip(), sentence_score_gpt))


import sys

rake_wo_preproc = sys.stdout
with open('outputRake3WOPreproc.txt', 'w') as f:
    sys.stdout = f

    # Iterate through the summary list and print the output
    for index, (row_summary_abs, row_summary_gpt) in enumerate(summary):
        print(f"Top 10 Sentences with the Highest Scores for Row {index + 1}:")
        
        # Print the abstract summary
        print("Abstract Summary:")
        # Sort sentences based on their scores
        sorted_sentences_abs = sorted(sent_tokenize(row_summary_abs)[:10], key=lambda x: sum(keyword_score_abstract.get(word, 0) for word in x.split()), reverse=True)
        for i, sentence_abs in enumerate(sorted_sentences_abs):
            # Calculate the score for the current sentence in the abstract
            sentence_score_abs = sum(keyword_score_abstract.get(word, 0) for word in sentence_abs.split())
            if sentence_score_abs > 0:
                print(f"Sentence {i + 1}: {sentence_abs.strip()} - Score: {sentence_score_abs}")
        print()

        # Print the ChatGPT summary
        print("ChatGPT Summary:")
        # Sort sentences based on their scores
        sorted_sentences_gpt = sorted(sent_tokenize(row_summary_gpt)[:10], key=lambda x: sum(keyword_score_gpt.get(word, 0) for word in x.split()), reverse=True)
        for i, sentence_gpt in enumerate(sorted_sentences_gpt):
            # Calculate the score for the current sentence in the GPT summary
            sentence_score_gpt = sum(keyword_score_gpt.get(word, 0) for word in sentence_gpt.split())
            if sentence_score_gpt > 0:
                print(f"Sentence {i + 1}: {sentence_gpt.strip()} - Score: {sentence_score_gpt}")
        print()

    sys.stdout = rake_wo_preproc


