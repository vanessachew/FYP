import nltk
import re
import string
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
import heapq
import pandas as pd

nltk.download('stopwords')
nltk.download('punkt')
nltk.download('wordnet')

# Load the DataFrame
df = pd.read_csv("Book1.csv")

# Function to remove special characters
def remove_special_characters(text):
    allowed_chars = set(string.ascii_letters + ' ')  # Define allowed characters
    clean_text = ''.join(char for char in text if char in allowed_chars)  # Filter out special characters
    return clean_text

# Define a function to remove links from a string
def remove_links(text):
    return re.sub(r'http\S+', '', text)

# Remove links
df["clean_text"] = df["abstract"].apply(remove_links)

# Convert text to lowercase
df["clean_text"] = df["clean_text"].str.lower()

# Remove special characters
df["clean_text"] = df["clean_text"].apply(remove_special_characters) 

# Load stopwords
stop_list = set(stopwords.words('english'))
stop_list.update(["extra", "certainly", "also", "always"])

# Remove stopwords
def remove_stopwords(text):
    words = text.split()
    clean_words = [word for word in words if word not in stop_list]
    clean_text = ' '.join(clean_words)
    return clean_text

# Apply stopwords removal
df["clean_text"] = df["clean_text"].apply(remove_stopwords)

# Tokenize the text into sentences
df['sentences'] = df['clean_text'].apply(nltk.sent_tokenize)

# Function to compute word frequency
def word_frequency(text):
    word_frequencies = {}
    for word in nltk.word_tokenize(text):
        if word not in stop_list:
            if word not in word_frequencies.keys():
                word_frequencies[word] = 1
            else:
                word_frequencies[word] += 1
    return word_frequencies



# import nltk
# import re
# import string
# from nltk.tokenize import sent_tokenize, word_tokenize
# from nltk.corpus import stopwords
# import heapq
# import pandas as pd

# nltk.download('stopwords')
# nltk.download('punkt')
# nltk.download('wordnet')

# def remove_square_brackets(text):
#     return re.sub(r'\[[0-9]*\]', ' ', text)

# def remove_extra_spaces(text):
#     return re.sub(r'\s+', ' ', text)

# def remove_special_characters_and_digits(text):
#     return re.sub('[^a-zA-Z]', ' ', text)

# def remove_punctuations(text):
#     words = nltk.word_tokenize(text)
#     words_without_punctuations = [word for word in words if word not in string.punctuation]
#     return " ".join(words_without_punctuations)

# def get_filtered_sentence_list(text, stopwords):
#     sentence_list = nltk.sent_tokenize(text)
#     filtered_sentence_list = [sentence for sentence in sentence_list if sentence.lower() not in stopwords]
#     return filtered_sentence_list

# def calculate_word_frequencies(text, stopwords):
#     word_frequencies = {}
#     words_without_punctuations = nltk.word_tokenize(text)
    
#     for word in words_without_punctuations:
#         if word not in stopwords:
#             if word not in word_frequencies:
#                 word_frequencies[word] = 1
#             else:
#                 word_frequencies[word] += 1

#     maximum_frequency = max(word_frequencies.values())

#     for word in word_frequencies:
#         word_frequencies[word] = word_frequencies[word] / maximum_frequency

#     return word_frequencies

# def calculate_sentence_scores(sentence_list, word_frequencies, stopwords):
#     sentence_scores = {}

#     for sentence in sentence_list:
#         for word in nltk.word_tokenize(sentence.lower()):
#             if word not in stopwords:
#                 if word in word_frequencies:
#                     if len(sentence.split(' ')) < 60:
#                         if sentence not in sentence_scores:
#                             sentence_scores[sentence] = word_frequencies[word]
#                         else:
#                             sentence_scores[sentence] += word_frequencies[word]

#     return sentence_scores

# def get_summary_sentences(sentence_scores):
#     summary_sentences = heapq.nlargest(10, sentence_scores, key=sentence_scores.get)
#     return summary_sentences

# def print_summary(summary_sentences, sentence_scores):
#     summary_list = [(sentence, sentence_scores[sentence]) for sentence in summary_sentences]

#     for i, (sentence, score) in enumerate(summary_list, 1):
#         print(f"{i}. {sentence}\n   Score: {score}\n")

# # Load the DataFrame
# df = pd.read_csv("Book1.csv")

# # Function to remove special characters
# def remove_special_characters(text):
#     allowed_chars = set(string.ascii_letters + ' ')  # Define allowed characters
#     clean_text = ''.join(char for char in text if char in allowed_chars)  # Filter out special characters
#     return clean_text

# # Define a function to remove links from a string
# def remove_links(text):
#     return re.sub(r'http\S+', '', text)

# # Remove links
# df["clean_text"] = df["abstract"].apply(remove_links)

# # Convert text to lowercase
# df["clean_text"] = df["clean_text"].str.lower()

# # Remove special characters
# df["clean_text"] = df["clean_text"].apply(remove_special_characters) 

# # Load stopwords
# stop_list = set(stopwords.words('english'))
# stop_list.update(["extra", "certainly", "also", "always"])

# # Remove stopwords
# def remove_stopwords(text):
#     words = text.split()
#     clean_words = [word for word in words if word not in stop_list]
#     clean_text = ' '.join(clean_words)
#     return clean_text

# # Apply stopwords removal
# df["clean_text"] = df["clean_text"].apply(remove_stopwords)

# # Tokenize the text into sentences
# df['sentences'] = df['clean_text'].apply(nltk.sent_tokenize)

# # Function to compute word frequency
# def word_frequency(text):
#     word_frequencies = {}
#     for word in nltk.word_tokenize(text):
#         if word not in stop_list:
#             if word not in word_frequencies.keys():
#                 word_frequencies[word] = 1
#             else:
#                 word_frequencies[word] += 1
#     return word_frequencies

# # Process PDF and compute summary for each row
# for index, row in df.iterrows():
#     doc_text = row['clean_text']
#     doc_text = remove_square_brackets(doc_text)
#     doc_text = remove_extra_spaces(doc_text)
#     form_doc_text = remove_special_characters_and_digits(doc_text)
#     text_without_punctuations = remove_punctuations(form_doc_text)

#     filtered_sentence_list = get_filtered_sentence_list(doc_text, stop_list)

#     word_frequencies = calculate_word_frequencies(text_without_punctuations, stop_list)
#     sentence_scores = calculate_sentence_scores(filtered_sentence_list, word_frequencies, stop_list)
#     summary_sentences = get_summary_sentences(sentence_scores)

#     df.at[index, 'summary_sentences'] = summary_sentences
#     df.at[index, 'sentence_scores'] = sentence_scores
