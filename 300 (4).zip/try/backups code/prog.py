# # possible stopwords list
# https://gist.github.com/sebleier/554280

# csv file converter: https://www.zamzar.com/convert/xlsx-to-csv/

# preprocessing: https://www.kaggle.com/code/sudalairajkumar/getting-started-with-text-preprocessing

# from openpyxl import load_workbook


import nltk
from nltk.corpus import stopwords
import pandas as pd
import re
# import spacy
import string
from collections import Counter
pd.options.mode.chained_assignment = None
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
# prints out everything within limit of 150 chars
pd.set_option('display.max_colwidth', 150)

# nltk.download('stopwords')
# print('STOPWORDS: ', stopwords.words('english'), '\n')

full_df = pd.read_csv("Book1.csv", nrows=5000)
df = full_df[["text/ abstract"]]
df["text/ abstract"] = df["text/ abstract"].astype(str)
# full_df.columns
full_df.head()

# df["text_lower"] = df["text/ abstract"].str.lower()

# drop the new column created in last cell
# df.drop(["text_lower"], axis=1, inplace=True)
# print(df)

PUNCT_TO_REMOVE = string.punctuation
def remove_punctuation(text):
    df["text/ abstract"].str.lower()
    """custom function to remove the punctuation"""
    return text.translate(str.maketrans('', '', PUNCT_TO_REMOVE))
print(df)

df["text_wo_punct"] = df["text/ abstract"].apply(lambda text: remove_punctuation(text))
print(df)

# # ", ".join(stopwords.words('english'))
# # STOPWORDS = set(stopwords.words('english'))
# def remove_stopwords(text):
#     """custom function to remove the stopwords"""
#     stop_list = ["-", "extra", "certainly", "also", "always"]
#     stop_list.extend(stopwords.words('english'))
#     return " ".join([word for word in str(text).split() if word not in stop_list])

# df["text_wo_stop"] = df["text_wo_punct"].apply(lambda text: remove_stopwords(text))
# # print(df.head())
# print(df)

# # count
# cnt = Counter()
# for text in df["text_wo_stop"].values:
#     for word in text.split():
#         cnt[word] += 1
        
# cnt.most_common(10)

# # print(cnt.most_common(10))

# FREQWORDS = set([w for (w, wc) in cnt.most_common(10)])
# def remove_freqwords(text):
#     """custom function to remove the frequent words"""
#     return " ".join([word for word in str(text).split() if word not in FREQWORDS])

# df["text_wo_stopfreq"] = df["text_wo_stop"].apply(lambda text: remove_freqwords(text))
# print(df.head())
















# # calling for specific cell 
# cell = sheet['A2']

# # Print the value of the cell
# print("Value of cell A1:", cell.value)

# # Printing column headers
# column_headers = [cell.value for cell in next(sheet.iter_rows(min_row=1, max_row=1))]

# # Printing data row by row with column headers
# print("Data from Excel Sheet:")
# print("=" * 30)  # Separator line

# for row in sheet.iter_rows(min_row=2, values_only=True):  # starting from row 2 assuming row 1 has headers
#     for col_idx, cell in enumerate(row):
#         print(f'{column_headers[col_idx]}: {cell}')
#     print()  # Empty line to separate rows

# print("=" * 30)  # Separator line
# print("End of Data")

# # Printing column headers
# column_headers = [cell.value for cell in next(sheet.iter_rows(min_row=1, max_row=1))]

# # Printing data row by row with column headers
# for row in sheet.iter_rows(min_row=2, values_only=True):  # starting from row 2 assuming row 1 has headers
#     for col_idx, cell in enumerate(row):
#         print(f'{column_headers[col_idx]}: {cell}')
#     print()  # Empty line to separate rows

# # Iterating through rows and columns
# for row in sheet.iter_rows(values_only=True):
#     for cell in row:
#         print('Row:', cell, '\n')

# for column in sheet.iter_cols(values_only=True):
#     for cell in column:
#         print('Column:', cell, '\n')

# # calling for specific cell 
# cell1 = sheet['A1']

# print(cell.value)
# for row in sheet.iter_rows(values_only=True):
#     print('Row: ', row)

# for column in sheet.iter_cols(values_only=True):
#     print('Column:', column)
