# 
import math
import nltk
from nltk.corpus import stopwords
import pandas as pd 
import string
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk import sent_tokenize, word_tokenize, PorterStemmer

nltk.download('stopwords')
nltk.download('punkt')

# Set display options
pd.set_option('display.max_colwidth', 250)

# Load the DataFrame
df = pd.read_csv("Book1.csv")
# df.info()

# # single column
# ======================================
# Preprocessing abstract/ text (single column)

# Function to remove special characters
# def remove_special_characters(text):
#     allowed_chars = set(string.ascii_letters + ' ')  # Define allowed characters
#     clean_text = ''.join(char for char in text if char in allowed_chars)  # Filter out special characters
#     return clean_text

# # Define a function to remove links from a string
# def remove_links(text):
#     rere.sub(r'http\S+', '', text)

# # Remove punctuation
# df["clean_text"] = df["abstract"].apply(lambda s: ' '.join(re.sub("[.,!?:;-='...@#_]", " ", s).split()))

# Remove links
df["clean_text"] = df["abstract"].apply(lambda s: ' '.join(re.sub(r'http\S+', '', s).split()))

# Convert text to lowercase
df["clean_text"] = df["clean_text"].str.lower()

# Remove special characters
# df["clean_text"] = df["clean_text"].apply(remove_special_characters) 

# Load stopwords
stop_list = stopwords.words('english')
stop_list.extend(["extra", "certainly", "also", "always"])

# Remove stopwords
def remove_stopwords(text):
    words = text.split()
    clean_words = [word for word in words if word not in stop_list]
    clean_text = ' '.join(clean_words)
    return clean_text

# Preprocess the 'name' column to remove newline characters
df['name'] = df['name'].str.strip()

# Apply stopwords removal
df["clean_text"] = df["clean_text"].apply(remove_stopwords)

# ======================================

# # Display the DataFrame
# print(df)

# TF-IDF
# calc freq matrix of words in each sentence
# sent: key, val: dict of word freq
def _create_frequency_matrix(sentences):
    frequency_matrix = {}
    stopWords = set(stopwords.words("english"))
    ps = PorterStemmer()

    for sent in sentences:
        freq_table = {}
        words = word_tokenize(sent)
        for word in words:
            word = word.lower()
            word = ps.stem(word)
            if word in stopWords:
                continue

            if word in freq_table:
                freq_table[word] += 1
            else:
                freq_table[word] = 1
        frequency_matrix[sent[:15]] = freq_table

    return frequency_matrix

# find term freq (TF): since only have one doc, doc=paragph, term=word in parag 
# generate a matrix:
def _create_tf_matrix(freq_matrix):
    tf_matrix = {}

    for sent, f_table in freq_matrix.items():
        tf_table = {}

        count_words_in_sentence = len(f_table)
        for word, count in f_table.items():
            tf_table[word] = count / count_words_in_sentence

        tf_matrix[sent] = tf_table

    return tf_matrix

# creating a table for doc/ words
# calc: how many sentences contain a word
def _create_documents_per_words(freq_matrix):
    word_per_doc_table = {}

    for sent, f_table in freq_matrix.items():
        for word, count in f_table.items():
            if word in word_per_doc_table:
                word_per_doc_table[word] += 1
            else:
                word_per_doc_table[word] = 1

    return word_per_doc_table

# calc idf matrix: 
def _create_idf_matrix(freq_matrix, count_doc_per_words, total_documents):
    idf_matrix = {}

    for sent, f_table in freq_matrix.items():
        idf_table = {}

        for word in f_table.keys():
            idf_table[word] = math.log10(total_documents / float(count_doc_per_words[word]))

        idf_matrix[sent] = idf_table

    return idf_matrix

# calc tf-idf & generate matrix
def _create_tf_idf_matrix(tf_matrix, idf_matrix):
    tf_idf_matrix = {}

    for (sent1, f_table1), (sent2, f_table2) in zip(tf_matrix.items(), idf_matrix.items()):

        tf_idf_table = {}

        for (word1, value1), (word2, value2) in zip(f_table1.items(),
                                                    f_table2.items()):  # here, keys are the same in both the table
            tf_idf_table[word1] = float(value1 * value2)

        tf_idf_matrix[sent1] = tf_idf_table

    return tf_idf_matrix

# score sentences

def _score_sentences(tf_idf_matrix) -> dict:
    sentenceValue = {}

    for sent, f_table in tf_idf_matrix.items():
        total_score_per_sentence = 0

        count_words_in_sentence = len(f_table)
        for word, score in f_table.items():
            total_score_per_sentence += score

        sentenceValue[sent] = total_score_per_sentence / count_words_in_sentence

    return sentenceValue

# find threshold: ave sentence score
def _find_average_score(sentenceValue) -> int:
    sumValues = 0
    for entry in sentenceValue:
        sumValues += sentenceValue[entry]

    # Average value of a sentence from original summary_text
    average = (sumValues / len(sentenceValue))

    return average

# generate a summary
def _generate_summary(sentences, sentenceValue, threshold, max_sentences=10):
    sentence_count = 0
    summary = ''

    for sentence in sentences:
        if sentence[:15] in sentenceValue and sentenceValue[sentence[:15]] >= (threshold):
            summary += " " + sentence
            sentence_count += 1

            # Stop summarizing when 10 sentences are included
            if sentence_count >= max_sentences:
                break

    return summary

# # generate a summary
# def _generate_summary(sentences, sentenceValue, threshold):
#     sentence_count = 0
#     summary = ''

#     for sentence in sentences:
#         if sentence[:15] in sentenceValue and sentenceValue[sentence[:15]] >= (threshold):
#             summary += " " + sentence
#             sentence_count += 1

#     return summary

# Iterate over each row
for index, row in df.iterrows():
    # Tokenize sentences from the 'clean_text' column of the current row
    sentences = sent_tokenize(row['clean_text'])
    
    # Count the total number of sentences in the current document
    total_sentences = len(sentences)

    # 2 Create the Frequency matrix of the words in each sentence.
    freq_matrix = _create_frequency_matrix(sentences)

    # 3 calc TF and generate a matrix
    tf_matrix = _create_tf_matrix(freq_matrix)

    # 4 creating table for documents per words
    count_doc_per_words = _create_documents_per_words(freq_matrix)

    # 5 Calculate IDF and generate a matrix
    idf_matrix = _create_idf_matrix(freq_matrix, count_doc_per_words, total_sentences)

    # 6 Calculate TF-IDF and generate a matrix
    tf_idf_matrix = _create_tf_idf_matrix(tf_matrix, idf_matrix)

    # 7 Important Algorithm: score the sentences
    sentence_scores = _score_sentences(tf_idf_matrix)

    # 8 Find the threshold
    threshold = _find_average_score(sentence_scores)

    # 9 Important Algorithm: Generate the summary
    summary = _generate_summary(sentences, sentence_scores, 1 * threshold, max_sentences=10)
    print(f"\nSummary for row {index}:\n{summary}")

    # print(summary)




# # ======================================

# # # Display the DataFrame
# # print(df)

# # # TF-IDF
# # calc freq matrix of words in each sentence
# # sent: key, val: dict of word freq
# def _create_frequency_matrix(sentences):
#     frequency_matrix = {}
#     stopWords = set(stopwords.words("english"))
#     ps = PorterStemmer()

#     for sent in sentences:
#         freq_table = {}
#         words = word_tokenize(sent)
#         for word in words:
#             word = word.lower()
#             word = ps.stem(word)
#             if word in stopWords:
#                 continue

#             if word in freq_table:
#                 freq_table[word] += 1
#             else:
#                 freq_table[word] = 1
#         frequency_matrix[sent[:15]] = freq_table

#     return frequency_matrix

# # find term freq (TF): since only have one doc, doc=paragph, term=word in parag 
# # generate a matrix:
# def _create_tf_matrix(freq_matrix):
#     tf_matrix = {}

#     for sent, f_table in freq_matrix.items():
#         tf_table = {}

#         count_words_in_sentence = len(f_table)
#         for word, count in f_table.items():
#             tf_table[word] = count / count_words_in_sentence

#         tf_matrix[sent] = tf_table

#     return tf_matrix

# # creating a table for doc/ words
# # calc: how many sentences contain a word
# def _create_documents_per_words(freq_matrix):
#     word_per_doc_table = {}

#     for sent, f_table in freq_matrix.items():
#         for word, count in f_table.items():
#             if word in word_per_doc_table:
#                 word_per_doc_table[word] += 1
#             else:
#                 word_per_doc_table[word] = 1

#     return word_per_doc_table

# # calc idf matrix: 
# def _create_idf_matrix(freq_matrix, count_doc_per_words, total_documents):
#     idf_matrix = {}

#     for sent, f_table in freq_matrix.items():
#         idf_table = {}

#         for word in f_table.keys():
#             idf_table[word] = math.log10(total_documents / float(count_doc_per_words[word]))

#         idf_matrix[sent] = idf_table

#     return idf_matrix

# # calc tf-idf & generate matrix
# def _create_tf_idf_matrix(tf_matrix, idf_matrix):
#     tf_idf_matrix = {}

#     for (sent1, f_table1), (sent2, f_table2) in zip(tf_matrix.items(), idf_matrix.items()):

#         tf_idf_table = {}

#         for (word1, value1), (word2, value2) in zip(f_table1.items(),
#                                                     f_table2.items()):  # here, keys are the same in both the table
#             tf_idf_table[word1] = float(value1 * value2)

#         tf_idf_matrix[sent1] = tf_idf_table

#     return tf_idf_matrix

# # score sentences

# def _score_sentences(tf_idf_matrix) -> dict:
#     """
#     score a sentence by its word's TF
#     Basic algorithm: adding the TF frequency of every non-stop word in a sentence divided by total no of words in a sentence.
#     :rtype: dict
#     """

#     sentenceValue = {}

#     for sent, f_table in tf_idf_matrix.items():
#         total_score_per_sentence = 0

#         count_words_in_sentence = len(f_table)
#         for word, score in f_table.items():
#             total_score_per_sentence += score

#         sentenceValue[sent] = total_score_per_sentence / count_words_in_sentence

#     return sentenceValue

# # find threshold: ave sentence score
# def _find_average_score(sentenceValue) -> int:
#     """
#     Find the average score from the sentence value dictionary
#     :rtype: int
#     """
#     sumValues = 0
#     for entry in sentenceValue:
#         sumValues += sentenceValue[entry]

#     # Average value of a sentence from original summary_text
#     average = (sumValues / len(sentenceValue))

#     return average

# # generate a summary
# def _generate_summary(sentences, sentenceValue, threshold):
#     sentence_count = 0
#     summary = ''

#     for sentence in sentences:
#         if sentence[:15] in sentenceValue and sentenceValue[sentence[:15]] >= (threshold):
#             summary += " " + sentence
#             sentence_count += 1

#     return summary

# # Iterate over each row
# for index, row in df.iterrows():
#     # Tokenize sentences from the 'clean_text' column of the current row
#     sentences = sent_tokenize(row['clean_text'])
    
#     # Count the total number of sentences in the current document
#     total_sentences = len(sentences)
    
#     # # Print the sentences for the current row
#     # print(f"Sentences for row {index}:")
#     # for sentence in sentences:
#     #     print(sentence)
    
#     # # Print the total number of sentences for the current row
#     # print(f"Total sentences for row {index}: {total_sentences}\n")

# # 2 Create the Frequency matrix of the words in each sentence.
# freq_matrix = _create_frequency_matrix(sentences)
# #print(freq_matrix)

# # 3 calc TF and generate a matrix
# tf_matrix = _create_tf_matrix(freq_matrix)

# # 4 creating table for documents per words
# count_doc_per_words = _create_documents_per_words(freq_matrix)
# #print(count_doc_per_words)

# # 5 Calculate IDF and generate a matrix
# idf_matrix = _create_idf_matrix(freq_matrix, count_doc_per_words, total_sentences)
# #print(idf_matrix)

# # 6 Calculate TF-IDF and generate a matrix
# tf_idf_matrix = _create_tf_idf_matrix(tf_matrix, idf_matrix)
# #print(tf_idf_matrix)

# # 7 Important Algorithm: score the sentences
# sentence_scores = _score_sentences(tf_idf_matrix)
# #print(sentence_scores)

# # 8 Find the threshold
# threshold = _find_average_score(sentence_scores)
# #print(threshold)

# # 9 Important Algorithm: Generate the summary
# summary = _generate_summary(sentences, sentence_scores, 1.4 * threshold)
# print(summary)





# version taht generates a vector 
# =========================================================
# # Initialize the TF-IDF vectorizer
# tfidf_vectorizer = TfidfVectorizer()

# # Fit and transform the clean_text column to get the TF-IDF matrix
# tfidf_matrix = tfidf_vectorizer.fit_transform(df['clean_text'])

# # Convert the TF-IDF matrix to a pandas DataFrame for better visualization
# tfidf_df = pd.DataFrame(tfidf_matrix.toarray(), columns=tfidf_vectorizer.get_feature_names_out())

# print(tfidf_df)

# # Obtain TF-IDF vectors for individual rows
# for index, row in df.iterrows():
#     text = row['clean_text']
#     tfidf_vector = tfidf_vectorizer.transform([text])
#     print(f"TF-IDF vector for row {index}: {tfidf_vector.toarray()}")

# # Obtain the number of rows and columns in the TF-IDF matrix
# num_rows, num_columns = tfidf_matrix.shape

# # Print out the number of rows and columns
# print(f"Number of rows in the TF-IDF matrix: {num_rows}")
# print(f"Number of columns in the TF-IDF matrix: {num_columns}")
    

# # Display all columns in the TF-IDF DataFrame
# with pd.option_context('display.max_columns', None):
#     print(tfidf_df)

# https://okan.cloud/posts/2022-01-16-text-vectorization-using-python-tf-idf/#:~:text=To%20calculate%20the%20TF%2DIDF,its%20TF%20and%20IDF%20values.&text=The%20TF%2DIDF%20value%20depends,of%20documents%20including%20the%20word.

# https://hackernoon.com/finding-the-most-important-sentences-using-nlp-tf-idf-3065028897a3
    