import nltk
from nltk.corpus import stopwords
import pandas as pd 
import string
import re

nltk.download('stopwords')

# Set display options
pd.set_option('display.max_colwidth', 250)

# Load the DataFrame
df = pd.read_csv("Book1.csv")
df.info()

# # single column
# =============================
# Preprocessing abstract/ text (single column)
# Remove links
df["clean_text"] = df["summary_5_sentences"].apply(lambda s: re.sub(r'http\S+', '', s))

# Convert text to lowercase
df["clean_text"] = df["clean_text"].str.lower()

# Remove punctuation
df["clean_text"] = df["clean_text"].apply(lambda s: re.sub(r'[^\w\s]', '', s))

# Load stopwords
stop_list = stopwords.words('english')
stop_list.extend(["-", "extra", "certainly", "also", "always"])

# Remove stopwords
def remove_stopwords(text):
    words = text.split()
    clean_words = [word for word in words if word not in stop_list]
    clean_text = ' '.join(clean_words)
    return clean_text

# Apply stopwords removal
df["clean_text"] = df["clean_text"].apply(remove_stopwords)

# Display the DataFrame
print(df)
# =============================

# import nltk
# from nltk.corpus import stopwords
# import pandas as pd 
# import string
# import re

# nltk.download('stopwords')

# # prints out everything within limit of 150 chars
# pd.set_option('display.max_colwidth', 150)

# df = pd.read_csv("Book1.csv")
# df.info()

# # this one is abstract
# # removing links 
# # max col: 25
# df["clean_text"] = df["text"].apply(lambda s: ' '.join(re.sub("(w+://S+)", " ", s).split()))    # getting rid of links
# df["clean_text"] = df["text"].apply(lambda s: re.sub(r'http\S+', '', s))
# df[['text','clean_text']].iloc[25]  # will output text & cleantext
# df["clean_text"] = df["text"].str.lower()   # make all letters lowercase
# df[['text','clean_text']]
# def remove_punct(text):
#     # Split the text into words
#     words = text.split()
    
# # remove punct    
# df["clean_text"] = df["clean_text"].apply(lambda s: ' '.join(re.sub(r'[!#$%&\'()*+,-./:;<=>?@\[\]^_`{|}~"]', ' ', s).split()))
# df[['text','clean_text']]

# # Load the stopwords from NLTK and extend them with your custom stop_list
# stop_list = stopwords.words('english')
# stop_list.extend(["-", "extra", "certainly", "also", "always"])
# # df["clean_text"] = " ".join([word for word in str("clean_text").split() if word not in stop_list])
# def remove_stopwords(text):

#     # Split the text into words
#     words = text.split()
#     # Remove stopwords and words in the stop_list
#     clean_words = [word for word in words if word.lower() not in stop_list]
#     # Join the clean words back into a string
#     clean_text = ' '.join(clean_words)
#     return clean_text
# # Apply the remove_stopwords function to the "clean_text" column
# df["clean_text"] = df["clean_text"].apply(remove_stopwords)

# print(df)

# =============
# df["clean_text"] = df["clean_text"].apply(lambda s: ' '.join(re.sub("["".,!?:;-='...@#_']", " ", s).split()))
# df["clean_text"].replace('d+', '', regex=True, inplace=True)  # get rid of numbers
# df[["text","clean_text"]]

# df["clean_text"] = df["text"].apply(lambda s: re.sub(r'http\S+', '', s))
# # df["clean_text"] = df["text"].apply(lambda s: ' '.join(re.sub("(w+://S+)", " ", s).split()))    # getting rid of links
# df[['text','clean_text']].iloc[25]  # will output text & cleantext
# df["clean_text"] = df["text"].str.lower()   # make all letters lowercase
# df[['text','clean_text']]

# # Load the stopwords from NLTK and extend them with your custom stop_list
# stop_list = stopwords.words('english')
# stop_list.extend(["-", "extra", "certainly", "also", "always"])

# # stop_list = ["-", "extra", "certainly", "also", "always"]
# # stop_list.extend(stopwords.words('english'))

# def remove_stopwords(text):
#     # Split the text into words
#     words = text.split()
#     # Remove stopwords and words in the stop_list
#     clean_words = [word for word in words if word.lower() not in stop_list]
#     # Join the clean words back into a string
#     clean_text = ' '.join(clean_words)
#     return clean_text

# # Apply the remove_stopwords function to the "clean_text" column
# df["clean_text"] = df["clean_text"].apply(remove_stopwords)

# # remove punctuation using string module
# df["clean_text"] = df["clean_text"].apply(lambda s: s.translate(str.maketrans('', '', string.punctuation)))
# # df["clean_text"] = df["clean_text"].apply(lambda s: ' '.join(re.sub(f"[{string.punctuation}]", " ", s).split()))

# # display the first 10 rows of the data frame
# df.head(10)

# print(df)

# # print(df.summary_15)